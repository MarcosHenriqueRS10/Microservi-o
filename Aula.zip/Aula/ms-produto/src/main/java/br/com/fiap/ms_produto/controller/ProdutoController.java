package br.com.fiap.ms_produto.controller;

import br.com.fiap.ms_produto.entities.Produto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    @GetMapping
    public ResponseEntity<List<Produto>> getProduto(){
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Produto(1L, "Smart TV", "Smart TV LED 29 polegadas", 2990.0));
        produtos.add(new Produto(2L, "Mouse Microsoft", "Mouse sem fio", 250.0));
        produtos.add(new Produto(3L, "Teclado Microsoft", "Teclado sem fio", 278.59));

        return ResponseEntity.ok(produtos);
    }


}
