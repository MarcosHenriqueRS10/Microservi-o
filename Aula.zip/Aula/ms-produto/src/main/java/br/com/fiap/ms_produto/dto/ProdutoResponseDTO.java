package br.com.fiap.ms_produto.dto;

public class ProdutoResponseDTO(
     Long id,
     String nome,
     String descricao,
     Double valor
) {

    public static ProdutoResponseDTO(){
        return new ProdutoResponseDTO(1L , "Smart TV",
                "Smart TV LED 29 polegadas");
    }
}