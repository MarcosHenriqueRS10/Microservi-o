package br.com.fiap.ms_produto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
